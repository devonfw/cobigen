# mercy
TypeScript AST Printer
